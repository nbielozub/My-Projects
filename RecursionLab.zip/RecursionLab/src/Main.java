import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.InvalidPathException;
import java.util.Scanner;

/**
 * @author Nadiia Bielozub
 *
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("*** File Search ***");
        System.out.println("Search for a particular type of file (.java, .docx, .jpg, etc.) in a folder");
//Gets input from the user on the folder name they would like to search
        Scanner myObj = new Scanner(System.in);
        File folder;
//Runs a loop with a conditional that checks if the folder name the user provides is valid.
// The program keeps asking the user for input if the one provided is invalid.
        do {
            System.out.print("Enter folder name that you wish to search: ");
            folder = new File(myObj.nextLine());
            if (!(folder.exists())) {
                System.out.println(folder + " is not valid.");
            }
        }
        while (!(folder.exists()));

        //Gets input from the user on the suffix that they would like to search for.
        System.out.print("Enter suffix that you wish to search for: ");
        String suffix = myObj.nextLine();

        //Implements a method that recursively searches for files with a matching suffix in the system.
        //The try/catch block handles exceptions that might occur while performing the search.
        try {
            search(folder, suffix);
        } catch (IOException | NullPointerException e) {
            System.out.println(e.getMessage());
        }
    }

// This method uses an array of files in the directory and checks if the specified folder name ends with the specified suffix that the user provides.
//If it does, the program prints the canonical path of the file with the matching suffix. (Which would also be the stopping condition)
//If it does not, the program goes through each file in the array and does a recursive call on the method itself to check the stopping condition again until the correct files are found.
    public static void search(File folder, String suffix) throws IOException {
        File[] files = folder.listFiles();
        if ((folder.getName()).endsWith(suffix)) {
            System.out.println(folder.getCanonicalPath());
        } else if (files != null) {
            for (File file : files) {
                    search(file, suffix);
                }

            }
        }
    }













